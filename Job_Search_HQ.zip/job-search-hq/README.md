# Job Search HQ — GitHub Pages deployment

Updated: November 17, 2026

## Publish

1. Copy the entire `job-search-hq` folder into the root of your existing `rymian4.github.io` GitHub Pages repository.
2. Commit and push both `index.html` and this README.
3. When Pages deploys, open `https://rymian4.github.io/job-search-hq/` (assuming that repository is serving the root of your existing GitHub Pages site).
4. Click **Import refreshed tracker**. Choose the separately downloaded file `Ryan_Job_Search_Refreshed_2026-11-17_PRIVATE.json`.
5. The tracker then displays your 148 jobs, 45 recruiter records, histories and newly verified leads. You can use Not applied / Applied / Rejected / Archived tabs to maintain the pipeline. Select checkboxes to bulk-mark responses as rejected.
6. After any major change, use **Back up progress** or **Backups & Updates → Export full backup** and store the JSON privately.

## Privacy / data safety

- **Do not upload the `_PRIVATE.json` backup to GitHub**, GitHub Issues, or a public folder. It contains personal application tracking, notes and recruiter contact information.
- `index.html` contains only six public, job-posting seed records and the tracker code. It does **not** include your private application history or recruiter database.
- Application data you import into the published site is saved in that browser's local storage. It is not published to the repository or synced between browsers/devices. Every browser/device needs its own private backup import.
- GitHub Pages is public hosting even though the tracker stores your working data locally. For more privacy, do not link the page publicly from your portfolio.
- Browser storage can be erased. Keep backups.

## What changed

- November 17 new-opportunities batch and re-verification of the existing Zillow opportunity
- Homebase and already-recorded rejected outcomes reconciled in the private backup
- Cleaner application table, inline status editing, batch rejection/archive, refreshed-role tab
- Recruiter outreach tabs, archive/restore, job-linked application status, and contact history retained
- Deadline-oriented dashboard for securing a role before the April 2027 wedding
- Private backup import/export workflow retained and tested

This is a static single-file app. No npm install or build system is required.
